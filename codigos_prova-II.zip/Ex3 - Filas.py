"""
EX3 - Fila (FIFO)

Enunciado (contexto)
Voce esta desenvolvendo o sistema de pedidos de uma lanchonete que trabalha
com delivery. Os pedidos chegam continuamente pelos canais de atendimento
(aplicativo, telefone e balcao) e a cozinha precisa prepara-los na ordem
exata em que foram recebidos, garantindo justica no atendimento.

Nenhum pedido pode "furar" a fila: o cliente que pediu primeiro deve ser
atendido primeiro. Esse e o principio FIFO (First In, First Out), que torna
a fila a estrutura de dados ideal para este cenario.

Esse contexto exige uma fila porque:
1. Pedidos devem ser processados estritamente na ordem de chegada.
2. Novos pedidos entram sempre no final; a cozinha retira sempre do inicio.
3. Qualquer outra estrutura (pilha, lista aleatoria) quebraria a ordem de
   chegada e seria injusta com os clientes que aguardam ha mais tempo.

Entradas do usuario
O programa exibe um menu numerado. O usuario digita o numero da opcao desejada.
Quando necessario, o programa solicita a descricao do pedido.

Opcoes do menu:
  1. Adicionar pedido          ->  informa: descricao do pedido
  2. Preparar proximo pedido   (dequeue — retira o primeiro da fila)
  3. Ver proximo pedido        (frente — consulta sem remover)
  4. Listar todos os pedidos   (do primeiro ao ultimo)
  0. Sair

Saidas esperadas
- Confirmacao de entrada do pedido na fila com sua descricao.
- Nome do pedido retirado da frente ao processar (dequeue).
- Pedido da frente ao consultar sem remover.
- Lista completa da fila, do primeiro ao ultimo a ser atendido, numerada.

Exemplo
Sequencia de opcoes digitadas pelo usuario:
  1  ->  X-Burguer com fritas
  1  ->  Combo vegano
  1  ->  Milk-shake baunilha
  3
  2
  4
  0

Saida (resumo):
Pedido recebido: X-Burguer com fritas
Pedido recebido: Combo vegano
Pedido recebido: Milk-shake baunilha
Proximo pedido: X-Burguer com fritas
Preparando: X-Burguer com fritas
Fila de pedidos (primeiro -> ultimo):
  [1] Combo vegano
  [2] Milk-shake baunilha
Encerrando.
"""

from collections import deque


class Fila:
    def __init__(self):
        self._dados: deque = deque()

    def enqueue(self, dado):
        self._dados.append(dado)

    def dequeue(self):
        if self.esta_vazia():
            return None
        return self._dados.popleft()

    def peek(self):
        if self.esta_vazia():
            return "Nenhum pedido depois."
        return self._dados[1]

    def esta_vazia(self):
        return len(self._dados) == 0

    def listar(self):
        return list(self._dados)


class FilaDePedidos:
    def __init__(self):
        self._fila = Fila()

    def adicionar_pedido(self, descricao: str):
        self._fila.enqueue(descricao)

    def preparar_pedido(self):
        return self._fila.dequeue()

    def proximo_pedido(self):
        return self._fila.peek()

    def esta_vazia(self):
        return self._fila.esta_vazia()

    def listar_pedidos(self):
        return self._fila.listar()


atendimento = FilaDePedidos()


def exibir_menu():
    pedidos = atendimento.listar_pedidos()
    print("\n========== FILA DE PEDIDOS — LANCHONETE ==========")
    if pedidos:
        print(f"  Proximo a preparar: {pedidos[0]}")
        print(f"  Pedidos na fila: {len(pedidos)}")
    else:
        print("  Fila vazia — nenhum pedido aguardando")
    print("---------------------------------------------------")
    print("  1. Adicionar pedido")
    print("  2. Preparar proximo pedido")
    print("  3. Ver proximo pedido (sem remover)")
    print("  4. Listar todos os pedidos")
    print("  0. Sair")
    print("===================================================")


def main():
    while True:
        exibir_menu()
        opcao = input("\nEscolha uma opcao: ").strip()

        match opcao:
            case "0":
                print("Encerrando.")
                break

            case "1":
                descricao = input("Descricao do pedido: ").strip()
                if descricao:
                    atendimento.adicionar_pedido(descricao)
                    print(f"Pedido recebido: {descricao}")
                else:
                    print("Descricao nao pode ser vazia")

            case "2":
                pedido = atendimento.preparar_pedido()
                if pedido is None:
                    print("Fila vazia — nenhum pedido para preparar")
                else:
                    print(f"Preparando: {pedido}")

            case "3":
                pedido = atendimento.proximo_pedido()
                if pedido is None:
                    print("Fila vazia")
                else:
                    print(f"Proximo pedido: {pedido}")

            case "4":
                pedidos = atendimento.listar_pedidos()
                if not pedidos:
                    print("Fila vazia — nenhum pedido aguardando")
                else:
                    print("\nFila de pedidos (primeiro -> ultimo):")
                    for i, p in enumerate(pedidos, 1):
                        print(f"  [{i}] {p}")

            case _:
                print("Opcao invalida")


if __name__ == "__main__":
    main()
