"""
EX2 - Pilha (LIFO)

Enunciado (contexto)
Voce e um desenvolvedor de software que precisa gerenciar suas tarefas do dia.
Durante o trabalho, e comum ser interrompido por novas demandas urgentes: um bug
critico aparece enquanto voce implementa uma funcionalidade, ou seu chefe pede
uma correcao antes de voce terminar o que estava fazendo.

A cada interrupcao, voce empilha a tarefa atual e passa para a nova.
Quando conclui a tarefa do topo, retoma a de baixo — exatamente como uma pilha
de papeis na mesa: o ultimo que entra e o primeiro que sai (LIFO).


O uso de pilhas é o mais adequado pois reflete como a situação aconteceria na vida real. No escritorio, quando
alguem vem te entregar um novo documento para completar, ele estará no topo da sua caixa de entrada ou em cima
do amontuado de papeis. O trabalho mais recente é o mais facil de acessar e reduz o tempo perdido buscando pela
tarefa com menor prazo. Assim reduzindo o risco de esquecer ou atrasar a entrega de algo importante.


Entrada do Usuario 0-4 (" " indica a seleção do menu correspondente):
Sequencia de opcoes digitadas pelo usuario:
  1  ->  Implementar login
  1  ->  Corrigir bug
  1  ->  Revisar PR
  1  ->  Conferir Cache
  1  ->  Limpar HD Secundario
  4  ->  "Listar todas as tarefas"
  3  ->  "Ver proxima tarefa"
  2  ->  "Concluir tarefa do topo"
  2  ->  "Concluir tarefa do topo"
  2  ->  "Concluir tarefa do topo"
  2  ->  "Concluir tarefa do topo"
  3  ->  "Ver proxima tarefa"
  0  ->  "Sair"

Saida (Esperada):
Tarefa empilhada: Implementar login

Tarefa empilhada: Corrigir bug #42

Tarefa empilhada: Revisar PR urgente

Tarefa empilhada: Cache

Tarefa empilhada: HD

Pilha de tarefas (topo -> base):
  [1] HD
  [2] Cache
  [3] Revisar PR urgente
  [4] Corrigir bug #42
  [5] Implementar login

Proxima tarefa: Cache

Tarefa concluida: HD

Proxima tarefa: Revisar PR urgente

Tarefa concluida: Cache

Proxima tarefa: Corrigir bug #42

Tarefa concluida: Revisar PR urgente

Proxima tarefa: Implementar login

Tarefa concluida: Corrigir bug #42

Proxima tarefa: Pilha vazia

Tarefa concluida: Implementar login

Encerrando.
"""

from collections import deque

class GerenciadorTarefas:
    def __init__(self):
        self._dados: deque = deque()

    def push(self, descricao: str):
        self._dados.append(descricao)

    def esta_vazia(self):
        return len(self._dados) == 0

    def concluir(self):
        if self.esta_vazia():
            return None
        return self._dados.pop()

    def ver_prox(self):
        if len(self._dados) < 2:  # Verifica se há pelo menos duas tarefas na pilha
            return None
        return self._dados[-2]  # Retorna o penultimo elemento da lista 
    
    def listar_tarefas(self):
        tarefas = []
        i = len(self._dados) - 1
        while i >= 0:
            tarefas.append(self._dados[i])
            i -= 1
        return tarefas

gerenciador = GerenciadorTarefas()

def exibir_menu():
    tarefas = gerenciador.listar_tarefas()
    print("\n========== GERENCIADOR DE TAREFAS ==========")
    if tarefas:
        print(f"  Tarefa atual (topo): {tarefas[0]}")
        print(f"  Tarefas pendentes: {len(tarefas)}")
    else:
        print("  Pilha vazia — nenhuma tarefa pendente")
    print("--------------------------------------------")
    print("  1. Empilhar nova tarefa")
    print("  2. Concluir tarefa do topo")
    print("  3. Ver proxima tarefa (sem remover)")
    print("  4. Listar todas as tarefas")
    print("  0. Sair")
    print("============================================")


def main():
    while True:
        exibir_menu()
        opcao = input("\nEscolha uma opcao: ").strip()

        match opcao:
            case "0":
                print("Encerrando.")
                break

            case "1":
                descricao = input("Descricao da tarefa: ").strip()
                if descricao:
                    gerenciador.push(descricao)
                    print(f"Tarefa empilhada: {descricao}")
                else:
                    print("Descricao nao pode ser vazia")

            case "2":
                tarefa = gerenciador.concluir()
                if tarefa is None:
                    print("Pilha vazia — nenhuma tarefa para concluir")
                else:
                    print(f"Tarefa concluida: {tarefa}")

            case "3":
                tarefa = gerenciador.ver_prox()
                if tarefa is None:
                    print("Pilha vazia ou apenas uma tarefa — nenhuma tarefa para ver")
                else:
                    print(f"Proxima tarefa: {tarefa}")

            case "4":
                tarefas = gerenciador.listar_tarefas()
                if not tarefas:
                    print("Pilha vazia — nenhuma tarefa pendente")
                else:
                    print("\nPilha de tarefas (Ultima adicionada -> Primeira adicionada):")
                    for i, t in enumerate(tarefas, 1):
                        print(f"  [{i}] {t}")

            case _:
                print("Opcao invalida")


if __name__ == "__main__":
    main()
