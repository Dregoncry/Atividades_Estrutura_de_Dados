"""
EX1 - Lista Duplamente Encadeada

Enunciado (contexto)
Voce esta desenvolvendo um reprodutor de playlists para uma radio web.
O locutor precisa navegar rapidamente entre as musicas para frente e para tras,
sem reiniciar a lista e sem copiar todos os itens para um vetor a cada comando.
Tambem precisa inserir musicas no inicio, no fim ou em uma posicao especifica,
e remover musicas durante a transmissao.

Esse contexto exige uma lista duplamente encadeada porque:
1. As musicas precisam ser acessadas nos dois sentidos (anterior e proxima).
2. Insercoes e remocoes no meio da playlist devem ser feitas com ajuste de ponteiros,
   sem deslocamento de todos os elementos.

Entradas do usuario
O programa exibe um menu numerado. O usuario digita o numero da opcao desejada.
Quando necessario, o programa solicita dados adicionais (nome da musica ou posicao).

Opcoes do menu:
  1. Adicionar musica no inicio
  2. Adicionar musica no fim
  3. Adicionar musica em posicao especifica  ->  informa: nome e posicao (inteiro >= 0)
  4. Remover musica                          ->  informa: nome da musica
  5. Tocar musica especifica                 ->  informa: nome da musica
  6. Proxima musica
  7. Musica anterior
  8. Listar playlist
  0. Sair

Saidas esperadas
- Confirmacao de insercao ou remocao com o nome da musica.
- Musica atual exibida apos navegacao (proxima/anterior) e apos tocar.
- Listagem da playlist em dois sentidos: inicio->fim e fim->inicio.

Exemplo
Sequencia de opcoes digitadas pelo usuario:
  2  ->  Musica_A   {adiciona musicas no fim da playlist}
  2  ->  Musica_B   {adiciona musicas no fim da playlist}
  2  ->  Musica_C   {adiciona musicas no fim da playlist}
  5  ->  Musica_B   {toca Musica_B e seleciona ela como atual}
  7                 {navega para anterior, deve mostrar Musica_A}
  6                 {navega para proxima, deve mostrar Musica_B}
  8                 {lista a playlist nos dois sentidos}
  0                 {encerra o programa}

Saida (resumo):
Adicionada no fim: Musica_A
Adicionada no fim: Musica_B
Adicionada no fim: Musica_C
Tocando agora: Musica_B
Musica atual: Musica_A
Musica atual: Musica_B
Inicio -> Fim : Musica_A <-> Musica_B <-> Musica_C
Fim -> Inicio : Musica_C <-> Musica_B <-> Musica_A
Encerrando.
"""


class No:
    def __init__(self, dado: any):
        self.dado: any = dado
        self.dir: "No" = None
        self.esq: "No" = None


class ReprodutorPlaylist:
    
    def __init__(self):
        self.tamanho: int = 0
        self.inicio: No = None
        self.fim: No = None
        self.atual: No = None
        self.tocando: No = None

    # ===== Operações de inserção =====
    def add_inicio(self, musica):
        novo = No(musica)
        
        if self.tamanho == 0:
            self.fim = novo
        else:
            novo.dir = self.inicio
            self.inicio.esq = novo

        self.inicio = novo
        if self.atual is None:
            self.atual = self.inicio
        self.tamanho += 1

    def add_fim(self, musica):
        novo = No(musica)

        if self.tamanho == 0:
            self.inicio = novo
        else:
            novo.esq = self.fim
            self.fim.dir = novo

        self.fim = novo
        if self.atual is None:
            self.atual = self.inicio
        self.tamanho += 1

    def add_posicao(self, posicao, musica):
        if posicao < 0 or posicao > self.tamanho:
            return False

        if posicao == 0:
            self.add_inicio(musica)
            return True

        if posicao == self.tamanho:
            self.add_fim(musica)
            return True

        novo = No(musica)
        aux = self.inicio

        for i in range(posicao - 1):
            aux = aux.dir

        novo.esq = aux
        novo.dir = aux.dir
        aux.dir.esq = novo
        aux.dir = novo
        self.tamanho += 1
        return True

    # ===== Operações da LDpE =====
    def _buscar_no(self, dado):
        aux = self.inicio
        while aux is not None:
            if aux.dado == dado:
                return aux
            aux = aux.dir
        return None

    def remover(self, musica):
        alvo = self._buscar_no(musica)
        if alvo is None:
            return False

        proximo_atual = self.atual
        if self.atual == alvo:
            proximo_atual = alvo.dir if alvo.dir is not None else alvo.esq

        # Remove da lista
        if alvo.esq is None:
            self.inicio = alvo.dir
        else:
            alvo.esq.dir = alvo.dir

        if alvo.dir is None:
            self.fim = alvo.esq
        else:
            alvo.dir.esq = alvo.esq

        self.atual = proximo_atual
        self.tamanho -= 1
        return True

    # ===== Controles =====
    def tocar(self, musica):
        no = self._buscar_no(musica)
        if no is None:
            return False
        self.atual = no
        self.tocando = no
        return True

    def proxima(self):
        if self.atual is None:
            return None
        if self.atual.dir is not None:
            self.atual = self.atual.dir
        return self.atual.dado

    def anterior(self):
        if self.atual is None:
            return None
        if self.atual.esq is not None:
            self.atual = self.atual.esq
        return self.atual.dado

    def musica_atual(self):
        return "Nenhuma" if self.atual is None else self.atual.dado

    def musica_tocando(self):
        return "Nenhuma" if self.tocando is None else self.tocando.dado

    # ===== Listagem =====
    def listar(self):
        frente = []
        tras = []
        
        aux = self.inicio
        while aux is not None:
            frente.append(aux.dado)
            aux = aux.dir
        
        aux = self.fim
        while aux is not None:
            tras.append(aux.dado)
            aux = aux.esq

        if not frente:
            return "Playlist vazia", "Playlist vazia"
        
        frente_str = ""
        for i, musica in enumerate(frente):
            frente_str += musica if i == 0 else " <-> " + musica
        
        tras_str = ""
        for i, musica in enumerate(tras):
            tras_str += musica if i == 0 else " <-> " + musica
        
        return frente_str, tras_str

player = ReprodutorPlaylist()

def exibir_menu():
    print("\n========== REPRODUTOR DE PLAYLIST ==========")
    print(f"  Tocando agora: {player.musica_tocando()}")
    print("--------------------------------------------")
    print("  1. Adicionar musica no inicio")
    print("  2. Adicionar musica no fim")
    print("  3. Adicionar musica em posicao especifica")
    print("  4. Remover musica")
    print("  5. Tocar musica especifica")
    print("  6. Proxima musica")
    print("  7. Musica anterior")
    print("  8. Listar playlist")
    print("  0. Sair")
    print("============================================")


def main():

    while True:
        exibir_menu()
        print(f"  Musica atual: {player.musica_atual()}")
        opcao = input("\nEscolha uma opcao: ").strip()

        match opcao:
            case "0":
                print("Encerrando.")
                break

            case "1":
                musica = input("Nome da musica: ").strip()
                if musica:
                    player.add_inicio(musica)
                    print(f"Adicionada no inicio: {musica}")

            case "2":
                musica = input("Nome da musica: ").strip()
                if musica:
                    player.add_fim(musica)
                    print(f"Adicionada no fim: {musica}")

            case "3":
                musica = input("Nome da musica: ").strip()
                try:
                    posicao = int(input("Posicao (0 = inicio): ").strip())
                    if musica and player.add_posicao(posicao, musica):
                        print(f"Adicionada na posicao {posicao}: {musica}")
                    else:
                        print("Posicao invalida")
                except ValueError:
                    print("Posicao deve ser um numero inteiro")

            case "4":
                musica = input("Nome da musica a remover: ").strip()
                if player.remover(musica):
                    print(f"Removida: {musica}")
                else:
                    print("Musica nao encontrada")

            case "5":
                musica = input("Nome da musica a tocar: ").strip()
                if player.tocar(musica):
                    print(f"Tocando agora: {player.musica_atual()}")
                else:
                    print("Musica nao encontrada")

            case "6":
                atual = player.proxima()
                if atual is None:
                    print("Playlist vazia")
                else:
                    print(f"Musica atual: {atual}")

            case "7":
                atual = player.anterior()
                if atual is None:
                    print("Playlist vazia")
                else:
                    print(f"Musica atual: {atual}")

            case "8":
                frente, tras = player.listar()
                print(f"\nInicio -> Fim : {frente}")
                print(f"Fim -> Inicio : {tras}")

            case _:
                print("Opcao invalida")


if __name__ == "__main__":
    main()
